package com.example.loginexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginExampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
