package com.example.loginexample.user;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
class UserCreator {

    @Autowired
    private UserRepository userRepository;

    @PostConstruct
    public void init() {
        userRepository.save(new User("Lim Zhong Ming", "ZhongMing","lzm@email.com",  new BCryptPasswordEncoder().encode("password")));
        // etc
    }
}