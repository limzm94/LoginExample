package com.example.loginexample;

import com.example.loginexample.role.Role;
import com.example.loginexample.role.RoleRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class LoginExampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoginExampleApplication.class, args);
    }

    @Bean
    public CommandLineRunner demo(RoleRepository roleRepo) {
        return (args) -> {
            Role role=new Role();
            role.setName("ROLE_MANAGER");
            roleRepo.save(role);
            Role role1=new Role();
            role1.setName("ROLE_CUSTOMER");
            roleRepo.save(role1);
        };
    }
}
